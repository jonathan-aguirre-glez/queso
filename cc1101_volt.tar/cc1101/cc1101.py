import io
import time
import queue
import struct
import pathlib
import secrets
import binascii
import threading
import subprocess


class TransmissionException(Exception):
    pass


class AckNotReceivedException(TransmissionException):
    pass


# BYTES_PER_PACKET = 60 - 4 - 1
BYTES_PER_PACKET = 60 - 4 - 4 - 4   # todo à verifier
# BYTES_HEADER = 42   # todo à verifier
BYTES_HEADER = 52   # todo à verifier
HEADER_BYTES = 6
PREAMBLE = b'\x42\x42\x42\x42'

# BYTES_PER_MSG_ID = 4
# BYTES_PER_MSG_LENGTH = 4
# BYTES_PER_MSG_HASH = 4


class CC1101():
    def __init__(self, address, channel, frequency, modulation, debug=False):
        self.address = address
        self.channel = channel
        self.frequency = frequency
        self.modulation = modulation
        self.debug = debug

        # Thread/process state
        self.thread = None
        self.process = None

        # Emission state
        self.emission_lock = threading.Lock()
        self.response_event = None
        self.response = None

        # Reception state
        self.receive_queue = queue.Queue()
        self.msg_id = None
        self.msg_hash = None
        self.msg_length = None
        self.msg_buffer = b''
        self.msg_source_address = None
        self.msg_ctr = None

    def start(self):
        if self.thread is not None:
            raise Exception("Start() already called")

        start_event = threading.Event()
        self.thread = threading.Thread(
            target=self._run,
            name="cc1101-subprocess",
            daemon=True,
            args=(start_event,)
        )

        self.thread.start()

        # Kill the process if "Ready" message did not appear
        if not start_event.wait(timeout=2):
            self._kill()

            raise TimeoutError("Bridge proccess did not start properly")

    # - 1st message frame :
    # -> msg_id + chunk_num(=0) + PREAMBLE + msg_length + msg_hash + message

    # msg_id       data[0:4]
    # chunk_number data[4:6]
    # msg_preamble data[6:10]
    # msg_lenght   data[10:14]
    # msg_hash     data[14:18]
    # msg_data     data[18:]
    # -> 42
    #
    # - following message frame :
    # -> msg_id + chunk_num(=0) + message
    #
    # msg_id       data[0:4]
    # chunk_number data[4:5]
    # inconnu      data[5]
    # msg_data     data[6:]
    # -> 52
    #
    def send_pkt(self, address, message: bytes):
        if len(message) > 60:  # Because CC1101 driver is stupid
            raise Exception("Maximum message size is 60")

        with self.emission_lock:
            self._debug("Lock acquired")

            command = "SEND{:02X}:{}\n".format(
                address,
                binascii.hexlify(message).decode('ascii')
            )
            self._debug(f"[CC1101 =>] {command}", True)
            self.response_event = threading.Event()
            self.process.stdin.write(command.encode('ascii'))
            self.process.stdin.flush()

            if not self.response_event.wait(timeout=2):
                self._kill()

                raise TimeoutError("Error while communicating with subprocess")

            if self.response:
                return
            else:
                raise AckNotReceivedException()

    def send_msg(self, destination_address: int, message: bytes):
        msg_id = secrets.token_bytes(4)
        msg_length = struct.pack('<L', len(message))
        msg_hash = struct.pack('<I', binascii.crc32(message))

        packets_content = PREAMBLE + msg_length + msg_hash + message

        # todo recalculer BYTES_PER_PACKET
        for i in range(0, len(packets_content), BYTES_HEADER):
            chunk = packets_content[i:i + BYTES_HEADER]

            packet_content = (
                # msg_id + struct.pack('<B', i // BYTES_PER_PACKET) + chunk
                msg_id + struct.pack('<H', i // BYTES_HEADER) + chunk
            )
            # print(f"PACKET {i // BYTES_HEADER}")
            self._debug(f"PACKET {i // BYTES_HEADER}")
            # print(f"packet_length  {len(packet_content)}")
            self._debug(f"packet_length  {len(packet_content)}")
            # print(f"chunk_data  {packet_content}")
            self._debug(f"chunk_data  {packet_content}")
            self.send_pkt(destination_address, packet_content)

    def get_msg(self, wait=None):
        """ Returns a message if one is available, otherwise returns None
        """
        try:
            if wait is None:
                return self.receive_queue.get(block=False)
            else:
                return self.receive_queue.get(block=True, timeout=wait)
        except queue.Empty:
            return None

    def _debug(self, msg, direction_out=None):
        if not self.debug:
            return

        if direction_out is None:
            prefix = "CC1101"
        elif direction_out:
            prefix = "CC1101 =>"
        else:
            prefix = "CC1101 <="

        print(f"{prefix} {msg}")

    def _kill(self):
        # FIXME wait the end of process
        if self.process is not None:
            self.process.kill()

    def _on_pkt_received(self, address, data):
        # Try to find the preamble
        data_preamble = data[6:10]
        chunk_number = struct.unpack('<H', data[4:6])[0]

        if data_preamble == PREAMBLE and chunk_number == 0:  # todo à verif 4 -> [4:6]
            self.msg_id = data[0:4]
            self.msg_length = struct.unpack('<L', data[10:14])[0]
            self.msg_hash = struct.unpack('<I', data[14:18])[0]
            self.msg_buffer = b''
            self.msg_source_address = address   # aucun sens avec le test suivant elif
            self.msg_ctr = 1

            # print(f"Expecting a message of length {self.msg_length}")
            self._debug(f"Expecting a message of length {self.msg_length}")
            # print(f"With hash {self.msg_hash}")
            self._debug(f"With hash {self.msg_hash}")

            self.msg_buffer += data[18:]

        # Message continuation
        elif (
            data[0:4] == self.msg_id
            and chunk_number == self.msg_ctr
            and address == self.msg_source_address  # aucun sens avec le test precedent

        ):
            self.msg_buffer += data[6:]
            self.msg_ctr += 1

        self._debug(f"chunk_num unpacked_  {chunk_number}")

        # Check if message is ended
        if len(self.msg_buffer) == self.msg_length:
            msg_hash = binascii.crc32(self.msg_buffer)
            # print(f"MESSAGE WAS ENDED")
            self._debug(f"MESSAGE WAS ENDED")

            if msg_hash == self.msg_hash:
                # print(f"HASH ok")
                self._debug(f"HASH ok")
                # Add message to queue
                self.receive_queue.put(
                    # (self.msg_source_address, self.msg_buffer)    # todo à revoir pour identifier sender
                    self.msg_buffer
                )

            # Reset state
            self.msg_id = None
            self.msg_hash = None
            self.msg_length = None
            self.msg_buffer = b''
            self.msg_source_address = None
            self.msg_ctr = None

    def _run(self, start_event):
        server_path = pathlib.Path(__file__).parent / 'server'
        self.process = subprocess.Popen(
            [
                server_path,
                '-a', str(self.address),
                '-c', str(self.channel),
                '-f', str(self.frequency),
                '-m', str(self.modulation)
            ],
            stdout=subprocess.PIPE,
            stdin=subprocess.PIPE,
        )
        try:
            self.animation = "|/-\\"
            self.idx = 0

            for line in io.TextIOWrapper(
                self.process.stdout,
                encoding="utf-8"
            ):

                print("Processing..." + self.animation[self.idx % len(self.animation)], end="\r")
                self.idx += 1
                # time.sleep(0.1)

                line = line.strip()
                self._debug(f"[CC1101 =>] {line}", False)

                if line == "Ready":
                    start_event.set()
                elif line == "SENDOK":
                    self.response = True
                    self.response_event.set()
                elif line == "SENDKO":
                    self.response = False
                    self.response_event.set()
                elif line.startswith("RCV"):
                    address = int(line[3:5], 16)
                    contents = binascii.unhexlify(line[12:])

                    self._on_pkt_received(address, contents)
        finally:
            self._kill()

        # print("[CC1101] Thread exited")
        self._debug("[CC1101] Thread exited")
