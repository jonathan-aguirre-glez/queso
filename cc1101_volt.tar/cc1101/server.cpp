#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "cc1100_raspi.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <poll.h>
#include <unistd.h>
#include <fcntl.h>
#include <wiringPi.h>
#include <wiringPiSPI.h>

#define PACKAGE    "CC1100 SW"
#define VERSION_SW "0.9.1"
#define STDIN_BUFFER_SIZE 256

//--------------------------[Global CC1100 variables]--------------------------
uint8_t Tx_fifo[FIFOBUFFER], Rx_fifo[FIFOBUFFER];
uint8_t My_addr, Tx_addr, Rx_addr, Pktlen, pktlen, Lqi, Rssi;
uint8_t rx_addr, sender, lqi;
int8_t rssi_dbm;

int cc1100_freq_select, cc1100_mode_select, cc1100_channel_select;
uint32_t check_state_timer = 0;

uint8_t cc1100_debug = 0; //set CC1100 lib in no-debug output mode
uint8_t tx_retries = 1;
uint8_t rx_demo_addr = 3;

CC1100 cc1100;

void print_help(int exval) {
	printf("%s,%s by CW\r\n", PACKAGE, VERSION_SW);
	printf("%s [-h] [-V] [-v] [-a My_Addr] [-c channel] [-f frequency] \r\n", PACKAGE);
	printf("          [-m modulation]\n\r\n\r");
	printf("  -h              			print this help and exit\r\n");
	printf("  -V              			print version and exit\r\n\r\n");
	printf("  -v              			set verbose flag\r\n");
	printf("  -a my address [1-255] 		set my address\r\n\r\n");
	printf("  -c channel 	[1-255] 		set transmit channel\r\n");
	printf("  -f frequency  [315,434,868,915]  	set ISM band\r\n\r\n");
	printf("  -m modulation [1,38,100,250,500,4]	set modulation\r\n\r\n");

	exit(exval);
}


void setupCC1101() {
  // Setup CC1101
  printf("Setup CC1101...\n");
  wiringPiSetup();
  cc1100.begin(My_addr); //inits RF module with main default settings
  cc1100.sidle(); //set to ILDE first
  // cc1100.set_mode(0x02); //set modulation mode 1 = GFSK_1_2_kb; 2 = GFSK_38_4_kb; 3 = GFSK_100_kb; 4 = MSK_250_kb; 5 = MSK_500_kb; 6 = OOK_4_8_kb
  // cc1100.set_ISM(0x02); //set ISM Band 1=315MHz; 2=433MHz; 3=868MHz; 4=915MHz
  // cc1100.set_channel(0x01); //set channel
  cc1100.set_output_power_level(0); //set PA level in dbm
  // cc1100.set_myaddr(My_addr); //set my own address

  cc1100.show_main_settings(); //shows setting debug messages to UART
  cc1100.show_register_settings(); //shows current CC1101 register values
  cc1100.receive();
}

void handle_cc1101() {
	// Check/fix the overflow/underflow every second
	if (millis() - check_state_timer >= 1000) {
		check_state_timer = millis();
		cc1100.check_state();
	}


  if (!cc1100.packet_available()) //checks if a packed is available
  {
    return;
  }

  uint8_t res = cc1100.get_payload(Rx_fifo, pktlen, rx_addr, sender, rssi_dbm, lqi);
  if (res == FALSE) {
    return;
  }

  printf("RCV%02X:", sender);
  for (uint8_t i = 0; i <= pktlen; i++) {
    printf("%02X", Rx_fifo[i]);
  }
  printf("\r\n");
}

int parse_hex(const char * buffer,
  const uint8_t size) {
  int val = 0;
  for (uint8_t i = 0; i < size; i++) {
    val = (val * 16);

    if (buffer[i] >= '0' && buffer[i] <= '9') {
      val += buffer[i] - '0';
    } else if (buffer[i] >= 'a' && buffer[i] <= 'f') {
      val += buffer[i] - 'a' + 10;
    } else if (buffer[i] >= 'A' && buffer[i] <= 'F') {
      val += buffer[i] - 'A' + 10;
    } else { // Invalid char
      return -1;
    }
  }

  return val;
}

void handle_stdin(char * buffer, uint8_t len) {
  // Check starts with send
  if (strncmp(buffer, "SEND", 4) != 0) {
    printf("Invalid command :(\n");
    return;
  }

  // Parse destination address
  int address = parse_hex( & buffer[4], 2);
  if (address == -1) {
    printf("Could not parse address :(\n");
    return;
  }
  printf("%d\n", address);

  // Check separator
  if (buffer[6] != ':') {
    printf("Invalid format :(\n");
    return;
  }

  // Now parse the rest
  unsigned int pktlen;
  for (pktlen = 0; pktlen * 2 + 7 < len; pktlen++) {
    int response = parse_hex( & buffer[pktlen * 2 + 7], 2);
    if (response == -1) {
      printf("Could not parse content at position %d\n", pktlen * 2 + 7);
      return;
    }

    Tx_fifo[pktlen + 3] = response;
  }

  printf("Sending...\n");

  uint8_t res = cc1100.sent_packet(My_addr, address, Tx_fifo, pktlen + 3, 2);
  if (res == 1) {
    printf("SENDOK\n");
  } else {
    printf("SENDKO\n");
		cc1100.receive();
  }

}

int main(int argc, char * argv[]) {
  //------------- command line option parser -------------------
	int opt;
	// no arguments given
	if(argc == 1) {
		fprintf(stderr, "This program needs arguments....\n\r\n\r");
		print_help(1);
	}

	while((opt = getopt(argc, argv, "hVva:c:f:m:")) != -1) {
		switch(opt) {
		case 'h':
			print_help(0);
			break;
		case 'V':
			printf("%s %s\n\n", PACKAGE, VERSION_SW);
			exit(0);
			break;
		case 'v':
			printf("%s: Verbose option is set `%c'\n", PACKAGE, optopt);
			cc1100_debug = 1;
			break;
		case 'a':
			My_addr = atoi (optarg);
			break;
		case 'c':
			cc1100_channel_select = atoi (optarg);
			break;
		case 'f':
			cc1100_freq_select = atoi (optarg);
			switch(cc1100_freq_select){
				case 315:
					cc1100_freq_select = 1;
					break;
				case 434:
					cc1100_freq_select = 2;
					break;
				case 868:
					cc1100_freq_select = 3;
					break;
				case 915:
					cc1100_freq_select = 4;
					break;
				}
			break;
			case 'm':
				cc1100_mode_select = atoi (optarg);

				switch(cc1100_mode_select){
				case 1:
					cc1100_mode_select = 1;
					break;
				case 38:
					cc1100_mode_select = 2;
					break;

				case 100:
					cc1100_mode_select = 3;
					break;
				case 250:
					cc1100_mode_select = 4;
					break;
				case 500:
					cc1100_mode_select = 5;
					break;
				case 4:
					cc1100_mode_select = 6;
					break;
				}
				break;
				case ':':
					fprintf(stderr, "%s: Error - Option `%c' needs a value\n\n", PACKAGE, optopt);
					print_help(1);
					break;
				case '?':
					fprintf(stderr, "%s: Error - No such option: `%c'\n\n", PACKAGE, optopt);
					print_help(1);
		}
	}

	// print all remaining options
	for(; optind < argc; optind++)
		printf("argument: %s\n", argv[optind]);

	//------------- welcome message ------------------------
	printf("Raspberry CC1101 SPI Library test\n");
  fflush(stdout);
  setupCC1101();
  printf("Ready\n");
  fflush(stdout);

  // Stdin variables
  // Configure stdin for non blocking
  int flags = fcntl(fileno(stdin), F_GETFL, 0);
  fcntl(fileno(stdin), F_SETFL, flags | O_NONBLOCK);

  char input_buffer[STDIN_BUFFER_SIZE];
  uint8_t input_buffer_pos = 0;
  int c;
	check_state_timer = millis();

  for (;;) {
    // Read STDIN
    while ((c = fgetc(stdin)) != EOF) {
      if (c == '\n' || input_buffer_pos == STDIN_BUFFER_SIZE) {
        input_buffer[input_buffer_pos] = '\0';

        handle_stdin(input_buffer, strlen(input_buffer));
        fflush(stdout);

        input_buffer_pos = 0;
      } else {
        input_buffer[input_buffer_pos] = c;
        input_buffer_pos++;
      }
    }

    handle_cc1101();
    fflush(stdout);
    delay(1); //delay to reduce system load
  }

  return 0;
}
