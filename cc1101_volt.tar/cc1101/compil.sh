#!/bin/bash
set -e

g++ -lwiringPi server.cpp cc1100_raspi.cpp -o server
